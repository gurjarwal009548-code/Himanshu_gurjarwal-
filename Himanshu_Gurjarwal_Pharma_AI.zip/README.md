# Himanshu_Gurjarwal Pharma AI

A GitHub Pages-ready, notes-based Pharma AI demo built from the supplied Pharmacy PDF.

## Run
Open `index.html` locally or publish the folder with GitHub Pages.

## Important
This version performs local keyword retrieval from the supplied PDF. It does **not** call an external LLM API, so it is not yet a full generative chatbot. For a production AI chatbot, connect this corpus to a backend/RAG service and keep the PDF as the primary source.
